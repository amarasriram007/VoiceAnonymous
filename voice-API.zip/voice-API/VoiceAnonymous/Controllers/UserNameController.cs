﻿using Microsoft.AspNetCore.Mvc;
using VoiceAnonymous.Models;

namespace VoiceAnonymous.Controllers
{
    [ApiController]
    [Route("api/UserName")]
    public class UserNameController : ControllerBase
    {
        private readonly IUserNameRepository _userNameRepository;
        public UserNameController(IUserNameRepository userNameRepository)
        {
            this._userNameRepository = userNameRepository;
        }

        [HttpGet]
        [Route("CheckUserNameNotUnique")]
        public IActionResult CheckUserNameNotUnique( string userName ) 
        {
            try
            {
                return Ok( _userNameRepository.CheckUniqueUserName( userName ) );
                
            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }


        [HttpPost]
        [Route("AddUserProfile")]
        public IActionResult AddUserProfile( UserNames UserProfile )
        {
            try
            {
                return Ok(_userNameRepository.AddUserName(UserProfile));

            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }


        [HttpPut]
        [Route("UpdateUserProfile")]
        public IActionResult UpdateUserProfile(UserNames UserProfile)
        {
            try
            {
                return Ok(_userNameRepository.UpdateUserData(UserProfile));

            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }


        [HttpGet]
        [Route("GetAllUserProfiles")]
        public IActionResult GetAllUserProfiles()
        {
            try
            {
                return Ok(_userNameRepository.GetAllUserProfiles());

            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }
        [HttpGet]
        [Route("GetUserProfileByUserName")]
        public IActionResult GetUserProfileByUserName( string UserName)
        {
            try
            {
                return Ok(_userNameRepository.GetUserProfileByUserName(UserName));

            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }


        [HttpPut]
        [Route("DeleteUserProfile")]
        public IActionResult DeleteUserProfile(string UserName)
        {
            try
            {
                return Ok(_userNameRepository.DeleteUserProfiles(UserName));

            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }


        [HttpGet]
        [Route("LoginPageAPI")]
        public IActionResult LoginPage(string UserName, string Password)
        {
            try
            {
                return Ok(_userNameRepository.LoginData(UserName, Password));
            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }


        [HttpGet]
        [Route("LogOutAPI")]
        public IActionResult LogOutAPI(string UserName)
        {
            try
            {
                return Ok(_userNameRepository.LogOut(UserName));
            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }
    }
}
