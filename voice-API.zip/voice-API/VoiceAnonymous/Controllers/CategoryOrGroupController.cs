﻿using Microsoft.AspNetCore.Mvc;
using VoiceAnonymous.Models;

namespace VoiceAnonymous.Controllers
{
    [ApiController]
    [Route("api/GroupOrCategory")]
    public class CategoryOrGroupController : ControllerBase
    {
        private readonly ICategoryOrGroupRepository _categoryOrGroupRepository;
        private readonly ICommentsRepository _commentsRepository;
        public CategoryOrGroupController(ICategoryOrGroupRepository categoryOrGroupRepository) 
        {
            this._categoryOrGroupRepository = categoryOrGroupRepository;
        }


        [HttpPost]
        [Route("CreateNewGroup")]
        public IActionResult CreateNewGroup(CommentCategories categories)
        {
            try
            {
                return Ok(_categoryOrGroupRepository.CreateGroupCategory(categories));

            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }


        [HttpGet]
        [Route("GetAllActiveGroups")]
        public IActionResult CreateNewGroup( )
        {
            try
            {
                return Ok(_categoryOrGroupRepository.GetAllGroups());

            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }


        [HttpPost]
        [Route("JoiningUserIntoNewGroup")]
        public IActionResult JoiningUserIntoNewGroup(string UserName, int groupid)
        {
            try
            {
                return Ok(_categoryOrGroupRepository.JoiningUserIntoGroup(UserName, groupid));

            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }

        [HttpDelete]
        [Route("DeleteGroupAndUnfollowingUsers")]
        public IActionResult DeleteGroupAndUnfollowingUsers(int groupId)
        {
            try
            {
                return Ok(_categoryOrGroupRepository.DeleteGroup(groupId));

            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }


        [HttpDelete]
        [Route("UserLeaveFromGroup")]
        public IActionResult UserLeaveFromGroup(string UserName, int groupid)
        {
            try
            {
                return Ok(_categoryOrGroupRepository.ExitFromGroup(UserName, groupid));

            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }


        [HttpGet]
        [Route("ShowJoinOrLeaveButton")]
        public IActionResult ShowJoinOrLeaveButton(string UserName, int groupid)
        {
            try
            {
                return Ok(_categoryOrGroupRepository.ShowJoinOrExitButton(UserName, groupid));

            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }


        [HttpGet]
        [Route("ToShowAllFollowersForAGroup")]
        public IActionResult ToShowAllFollowersForAGroup( int groupId)
        {
            try
            {
                return Ok(_categoryOrGroupRepository.FollowingListForeachGroup(groupId));

            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }


        [HttpGet]
        [Route("SearchAllGroups")]
        public IActionResult SearchAllGroups(string searchText)
        {
            try
            {
                double minimumSimilarity = 75.0;
                IEnumerable<CommentCategories> searchResults = _categoryOrGroupRepository.SearchAllGroups(searchText, minimumSimilarity);
                return Ok(searchResults);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintenance");
            }
        }


        [HttpGet]
        [Route("TrendingHashTags")]
        public IActionResult TrendingHashTags()
        {
            try
            {
                return Ok(_categoryOrGroupRepository.TrendingTop3Categories());

            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }
    }
}
