﻿using Amazon.Comprehend;
using Amazon.Comprehend.Model;
using Microsoft.AspNetCore.Mvc;
using VoiceAnonymous.Models;

namespace VoiceAnonymous.Controllers
{
    [ApiController]
    [Route("api/Comment")]
    public class CommentController : ControllerBase
    {
        private readonly ICommentsRepository commentRepository;
        public CommentController(ICommentsRepository commentRepository) 
        { 
            this.commentRepository = commentRepository;
        }

        [HttpGet]
        [Route("GetAllComments")]
        public IActionResult GetAllComments() 
        {
            try
            {
                var AllItems = commentRepository.GetAll();
                return Ok(AllItems);
            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }           
        }


        [HttpGet]
        [Route("GetCommentByCommentId")]
        public IActionResult GetCommentByCommentId(int commentId)
        {
            try
            {
                var AllItems = commentRepository.GetCommentById( commentId );
                return Ok(AllItems);
            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }


        [HttpGet]
        [Route("GetCommentsByUserNameId")]
        public IActionResult GetCommentsByUserNameId(string UserName)
        {
            try
            {
                var AllItems = commentRepository.GetCommentsByUserNameIds( UserName );
                return Ok(AllItems);
            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }


        [HttpGet]
        [Route("GetTimeIntoHoursAgo")]
        public IActionResult GetTimeIntoHoursDaysAgo(int commentId)
        {
            try
            {
                var AllItems = commentRepository.GetTimeIntoHoursDaysAgoConverter(commentId);
                return Ok(AllItems);
            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }


        [HttpPut]
        [Route("UpdateComment")]
        public IActionResult UpdateComment( Comment comment )
        {
            try
            {
                var AllItems = commentRepository.UpdateComment(comment);
                return Ok(AllItems);
            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }


        [HttpPut]
        [Route("UpdateCommentVisibilty")]
        public IActionResult UpdateCommentVisibilty(int CommentId, string ViewOrHide)
        {
            try
            {
                var AllItems = commentRepository.ViewOrHideComment(CommentId, ViewOrHide);
                return Ok(AllItems);
            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }


        [HttpPut]
        [Route("UpdateCategoryForComment")]
        public IActionResult UpdateCategoryForComment(int CommentId, int categoryId)
        {
            try
            {
                var AllItems = commentRepository.UpdateCategoryIdIfChanged(CommentId, categoryId);
                return Ok(AllItems);
            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }


        [HttpPost]
        [Route("AddComment")]
        public IActionResult AddNewComment(Comment comment)
        {
            try
            {
                var AllItems = commentRepository.AddNewComments(comment);
                return Ok(AllItems);
            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }


        [HttpPut]
        [Route("IncreamentUpdateLikesCount")]
        public IActionResult IncreamentUpdateLikesCount(int commentId, string commentUserName)
        {
            try
            {
                var AllItems = commentRepository.UpdateLikesCounts(commentId, commentUserName);
                return Ok(AllItems);
            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }


        [HttpPut]
        [Route("IncreamentUpdateViewsCount")]
        public IActionResult IncreamentUpdateViewsCount(int commentId, string commentUserName)
        {
            try
            {
                var AllItems = commentRepository.UpdateViewsCounts(commentId, commentUserName);
                return Ok(AllItems);
            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }


        [HttpPut]
        [Route("DecreamentUpdateLikesCount")]
        public IActionResult DecreamentUpdateLikesCount(int commentId, string commentUserName)
        {
            try
            {
                var AllItems = commentRepository.DecreamentUpdateLikesCounts(commentId, commentUserName);
                return Ok(AllItems);
            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }


        [HttpDelete]
        [Route("DeactivateComment")]
        public IActionResult DeactivateComment(int commentId, string commentUserName)
        {
            try
            {
                var AllItems = commentRepository.DeleteOrDeactivateComment(commentId, commentUserName);
                return Ok(AllItems);
            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }


        [HttpPost]
        [Route("AddNewSubCommentForComment")]
        public IActionResult AddNewSubCommentForComment(SubComments subComments)
        {
            try
            {
                var AllItems = commentRepository.AddNewSubComments(subComments);
                return Ok(AllItems);
            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }


        [HttpGet]
        [Route("GetSubCommentByCommentId")]
        public IActionResult GetSubCommentByCommentId(int commentId)
        {
            try
            {
                var AllItems = commentRepository.GetAllSubCommentsByCommentId(commentId);
                return Ok(AllItems);
            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }

        [HttpDelete]
        [Route("DeleteSubComment")]
        public IActionResult DeleteSubComment(int SubcommentId, string Username)
        {
            try
            {
                var AllItems = commentRepository.DeleteSubComment(SubcommentId, Username);
                return Ok(AllItems);
            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }


        [HttpPut]
        [Route("EditSubComment")]
        public IActionResult EditSubComment(SubComments subComments)
        {
            try
            {
                var AllItems = commentRepository.EditSubComment(subComments);
                return Ok(AllItems);
            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }


        [HttpGet]
        [Route("GetAllLikesByCommentId")]
        public IActionResult GetAllLikesByCommentId(int commentId)
        {
            try
            {
                var AllItems = commentRepository.GetAllLikesByCommentId(commentId);
                return Ok(AllItems);
            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }


        [HttpGet]
        [Route("GetCommentsByHashTagSearch")]
        public IActionResult GetCommentsByHashTagSearch(string HashTag )
        {
            try
            {
                var AllItems = commentRepository.GetAllCommentsByHashTag(HashTag);
                return Ok(AllItems);
            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }


        [HttpGet]
        [Route("ShowLikeOrDisikeButton")]
        public IActionResult ShowLikeOrDisikeButton(int commentId, string userName)
        {
            try
            {
                var AllItems = commentRepository.GetLikeButtonStatus(commentId, userName);
                return Ok(AllItems);
            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }


        [HttpGet]
        [Route("TrendingComments")]
        public IActionResult TrendingComments()
        {
            try
            {
                var AllItems = commentRepository.GetAllTrendingCommments();
                return Ok(AllItems);
            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }


        [HttpGet]
        [Route("GetSentimentForText")]
        public async Task<IActionResult> GetSentimentForText(string commentText)
        {
            try
            {
                AmazonComprehendClient comprehendClient = new AmazonComprehendClient("ASIAYBFB6MBDFBAYZW3R",
                    "7gdKCcv9HNQJkKYi39oJ77UJ91JP5rdFSJt67tWP",
                    "IQoJb3JpZ2luX2VjEJf//////////wEaCXVzLXdlc3QtMiJHMEUCIHAZz9hC6SeWXdFdxNx74T7rIStUNYoLICgW+NRF+FUZAiEA4HNhlbo5Ax+U3pcWfRO66azNhoGulKEhSyahzcrC8qUqxgMI0P//////////ARACGgw1NTIyNDI5Mjk3MzQiDHsONx0mwleLuW8wJiqaA+z9lYaVftO0tykCOWwLR1lfzOYJFH/3NAn56w924yR3rX0FdzlOfox5EnIDuN0rqWA/VIaMfd6fsX6nWVbD+F40mXOQBqQpkb635yyB4o0+qdRR+0EOVYjiKZn2fkREhGXd04BvvutGHOLukfG1bKOoG1Ct5BO3gsGrdhtBGg7tXfudkaFChklZn26t7tTK5bYmHE0j5a2qko2eGjPA9vNowi13aGjcpV01TaJa/xMM+ze+Gdi/TA/XSxoLEHHqgj7lyTmJ1oKiTSvxca0hzaj22e27QZfaPKw7jidXfe3YyBxgiEM+daseN3YfFGGw1CcP/8SLacthE4HA/6Y8M5VvBULJT21ZZ+RnsQi9Af9FmnbqCMsAcYtG9s6WvELbE66QiGOJKt3xRDKUjfbri3YTLm4UsrjxVH56csM8qd8K4QZXSpA0jtHHBnSXUatRmEaBrE1DMwRmPGAqHQMZzYPDRlyvPl7oIyMPkr8DhwrS5yC2bOYBC/4GRi5/cOyl1vbsUQkeVGq3b3kQrVMaBKevWlNlCMGdbBf8MMGY5qMGOqYBTJ2wEKo5TBZrqvFuGbBfBkHdQd+caDIHFUNYS48V/5infNSyV7E6LbkgsO57n4JemJQxPLVIuh6Bny4ppMa5cQQ/1fesRITy10JrqbYeEhjYXDuEr1YmJ1hCXO8h2m6kMe9vBDuIXh4DVBcZz4KJXftoxIf72anHiHiwHLyLpyCJTBPZj5ORDYIZTsiD1lIn/GkjerTOitsqXBjOLeBebtuGweLIAA==",
                    Amazon.RegionEndpoint.USWest2);
               // Call DetectDominantLanguage API
                DetectSentimentRequest detectSentimentRequest = new DetectSentimentRequest()
                {
                    Text = commentText,
                    LanguageCode = "en"
                };
                var commentSentiment = await comprehendClient.DetectSentimentAsync(detectSentimentRequest);
                return Ok(commentSentiment.Sentiment);
            }
            catch (Exception ex)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }

    }
}
