﻿using Microsoft.AspNetCore.Mvc;
using VoiceAnonymous.Models;

namespace VoiceAnonymous.Controllers
{

    [ApiController]
    [Route("api/Followers")]
    public class Followers : ControllerBase
    {
        private readonly IFollowerRepository followerRepository;
        public Followers(IFollowerRepository followerRepository)
        {
            this.followerRepository = followerRepository;
        }


        [HttpGet]
        [Route("GetAllFollowers")]
        public IActionResult GetAllFollowers(string UserName)
        {
            try
            {
                return Ok(followerRepository.GetAllFollwersForSelectedUser(UserName));

            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }


        [HttpGet]
        [Route("GetFollowOrUnfollowButtonStatus")]
        public IActionResult GetFollowOrUnfollowButtonStatus(string UserName, string FollowedUserName)
        {
            try
            {
                return Ok(followerRepository.GetFollowButtonStatus(UserName, FollowedUserName));

            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }


        [HttpPost]
        [Route("AddNewFollower")]
        public IActionResult AddNewFollower(string UserName, string FollowedUserName)
        {
            try
            {
                return Ok(followerRepository.AddFollower(UserName, FollowedUserName));

            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }


        [HttpDelete]
        [Route("RemoveAnyFollowerIfFollowed")]
        public IActionResult RemoveAnyFollowerIfFollowed(string UserName, string FollowedUserName)
        {
            try
            {
                return Ok(followerRepository.RemoveFollower(UserName, FollowedUserName));

            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }


        [HttpGet]
        [Route("GetFollowingUsers")]
        public IActionResult GetFollowingUsers(string UserName)
        {
            try
            {
                return Ok(followerRepository.FollowingList(UserName));

            }
            catch (Exception)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, "ServerError Site Or Under Maintanance");
            }
        }
    }
}
