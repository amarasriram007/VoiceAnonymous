﻿namespace VoiceAnonymous.Models
{
    public interface ICommentsRepository
    {
        public IEnumerable<Comment> GetAll();
        public Comment GetCommentById(int CommentId);
        public IEnumerable<Comment> GetCommentsByUserNameIds(string UserName);
        public bool UpdateComment(Comment comment);
        public string UpdateCategoryIdIfChanged(int CommentId, int categoryId);
        public bool AddNewComments(Comment comment);
        public string ViewOrHideComment(int CommentId, string ViewOrHide);
        public string DeleteOrDeactivateComment(int commentId, string UserName);
        public bool UpdateLikesCounts(int commentId, string commentUserName);
        public bool UpdateViewsCounts(int commentId, string commentUserName);
        public bool DecreamentUpdateLikesCounts(int commentId, string commentUserName);
        public string GetTimeIntoHoursDaysAgoConverter(int commentId);
        public bool AddNewSubComments(SubComments SubComment);
        public IEnumerable<SubComments> GetAllSubCommentsByCommentId(int commentId);
        public string DeleteSubComment(int SubCommentId, string username);
        public string EditSubComment(SubComments subComments);
        public IEnumerable<Likes> GetAllLikesByCommentId(int commentId);
        public IEnumerable<Comment> GetAllCommentsByHashTag(string hashTag);
        public bool GetLikeButtonStatus(int commentId, string UserName);
        public IEnumerable<Comment> GetAllTrendingCommments();
    }
}
