﻿using System.ComponentModel.Design;
using System.Security.Cryptography;
using System.Security.Cryptography.Xml;
using System.Text;

namespace VoiceAnonymous.Models
{
    public class UserNameRepository : IUserNameRepository
    {
        private readonly AppDbContext appDbContext;
        private const string EncryptionKey = "2JZ3a$7oFb9p@5Kc";
        public UserNameRepository(AppDbContext appDbContext)
        {
            this.appDbContext = appDbContext;
        }


        public bool CheckUniqueUserName(string userName)
        {
            return appDbContext.UserNamesTable.Any(x => x.UserName == userName);
        }


        public bool AddUserName(UserNames UserProfile)
        {
            if (!CheckUniqueUserName(UserProfile.UserName) && UserProfile.UserName != null && !CheckUniqueMail(UserProfile.Email) && !CheckUniquePhoneNumber(UserProfile.PhoneNumber))
            {
                if (UserProfile.password == UserProfile.ConfirmPassword)
                {
                    UserProfile.PhoneNumber = EncryptData(UserProfile.PhoneNumber);
                    UserProfile.password = EncryptData(UserProfile.password);
                    UserProfile.ConfirmPassword = EncryptData(UserProfile.ConfirmPassword);
                    UserProfile.IsActive = true;
                    var entity = this.appDbContext.UserNamesTable.Add(UserProfile);
                    this.appDbContext.SaveChanges();
                    return true;
                }
            }
                return false;       
        }


        public bool UpdateUserData(UserNames UserProfile)
        {
            if (UserProfile.password == UserProfile.ConfirmPassword)
            {
                UserProfile.PhoneNumber = EncryptData(UserProfile.PhoneNumber);
                UserProfile.password = EncryptData(UserProfile.password);
                UserProfile.ConfirmPassword = EncryptData(UserProfile.ConfirmPassword);
                this.appDbContext.UserNamesTable.Update(UserProfile);
                this.appDbContext.SaveChanges();
                return true;
            }
            return false;
        }


        public bool CheckUniqueMail(string Email)
        {
            return this.appDbContext.UserNamesTable.Any(x => x.Email == Email );
        }


        public bool CheckUniquePhoneNumber(string PhoneNumber)
        {
            return this.appDbContext.UserNamesTable.Any(x => x.PhoneNumber == PhoneNumber );
        }


        public IEnumerable<UserNames> GetAllUserProfiles()
        {
            var UserProfiles = this.appDbContext.UserNamesTable.Where(x => x.IsActive);
            return UserProfiles;
        }


        public UserNames GetUserProfileByUserName(string UserName)
        {
            var UserProfile = this.appDbContext.UserNamesTable.SingleOrDefault(x => x.UserName == UserName && x.IsActive);
            if (UserProfile != null)
            {
                UserProfile.PhoneNumber = DecryptData(UserProfile.PhoneNumber);
                UserProfile.password = DecryptData(UserProfile.password);
                UserProfile.ConfirmPassword = DecryptData(UserProfile.ConfirmPassword);
                return UserProfile;
            }
            return UserProfile;
        }


        public string DeleteUserProfiles(string UserName)
        {
            var UserExist = this.appDbContext.UserNamesTable.Any( x => x.UserName == UserName);
            if (UserName != null && UserExist)
            {
                var commentsByUser = this.appDbContext.CommentTable.Where(x => x.UserName == UserName);
                var AllSubCommentsByUser = this.appDbContext.SubCommentsTable.Where(x => x.UserName == UserName);
                var AlllikesByUser = this.appDbContext.LikesTable.Where(x => x.UserName == UserName);
                var RemoveUserFromGroups = this.appDbContext.GroupCategoryFollowerTable.Where(x => x.UserName == UserName);
                var RemoveFollowingFollowers = this.appDbContext.FollowerTable.Where( x => x.UserName == UserName || x.FollowedUserName == UserName);
                var ViewsByUser = this.appDbContext.ViewsTable.Where( x => x.UserName == UserName);
                if (commentsByUser != null)
                {
                    List<CommentHashTag> commentHashTags = new List<CommentHashTag>();
                    foreach (var commentItem in commentsByUser)
                    {
                        var HashTag = this.appDbContext.CommentHashTagsTable.Where(x => x.CommentIds == commentItem.CommentId);
                        if(HashTag != null)
                        {
                            commentHashTags.AddRange(HashTag);
                        }
                    }
                    if (commentHashTags != null)
                    {
                        this.appDbContext.CommentHashTagsTable.RemoveRange(commentHashTags);
                        this.appDbContext.SaveChanges();
                    }
                    this.appDbContext.CommentTable.RemoveRange(commentsByUser);
                    this.appDbContext.SaveChanges();
                }
                if (AllSubCommentsByUser != null)
                {
                    this.appDbContext.SubCommentsTable.RemoveRange(AllSubCommentsByUser);
                    this.appDbContext.SaveChanges();
                }
                if (AlllikesByUser != null)
                {
                    this.appDbContext.LikesTable.RemoveRange(AlllikesByUser);
                    this.appDbContext.SaveChanges();
                }
                if(RemoveUserFromGroups != null)
                {
                    this.appDbContext.GroupCategoryFollowerTable.RemoveRange(RemoveUserFromGroups);
                    this.appDbContext.SaveChanges();
                }
                if (RemoveFollowingFollowers != null)
                {
                    this.appDbContext.FollowerTable.RemoveRange(RemoveFollowingFollowers);
                    this.appDbContext.SaveChanges();
                }
                if (ViewsByUser !=null)
                {
                    this.appDbContext.ViewsTable.RemoveRange(ViewsByUser); 
                    this.appDbContext.SaveChanges();
                }
                var Userprofile = this.appDbContext.UserNamesTable.SingleOrDefault(x => x.UserName == UserName);
                this.appDbContext.UserNamesTable.Remove(Userprofile);
                this.appDbContext.SaveChanges();
                return "Successfully Deleted";
            }
            return "Request for Deletion Unsuccessful";
        }


        public string EncryptData(string phoneNumber)
        {
            byte[] encryptedBytes;
            using (Aes aes = Aes.Create())
            {
                aes.Key = Encoding.UTF8.GetBytes(EncryptionKey);
                aes.IV = new byte[16]; 
                ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV);

                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write))
                    {
                        byte[] phoneNumberBytes = Encoding.UTF8.GetBytes(phoneNumber);
                        cs.Write(phoneNumberBytes, 0, phoneNumberBytes.Length);
                        cs.FlushFinalBlock();
                        encryptedBytes = ms.ToArray();
                    }
                }
            }
            return Convert.ToBase64String(encryptedBytes);
        }


        public string DecryptData(string encryptedPhoneNumber)
        {
            byte[] encryptedBytes = Convert.FromBase64String(encryptedPhoneNumber);
            string decryptedPhoneNumber;
            using (Aes aes = Aes.Create())
            {
                aes.Key = Encoding.UTF8.GetBytes(EncryptionKey);
                aes.IV = new byte[16]; 
                ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV);

                using (MemoryStream ms = new MemoryStream(encryptedBytes))
                {
                    using (CryptoStream cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader sr = new StreamReader(cs))
                        {
                            decryptedPhoneNumber = sr.ReadToEnd();
                        }
                    }
                }
            }
            return decryptedPhoneNumber;
        }


        public string LoginData(string username, string password)
        {
            var userData = this.GetUserProfileByUserName(username);
            if (username != null || password != null)
            {
                if (userData != null)
                {
                    if (userData.UserName == username && userData.password == password)
                    {
                        return userData.UserName;
                    }
                }
            }
            return "Login Failed";
        }


        public bool LogOut(string username)
        {
            return true;
        }

    }
}
