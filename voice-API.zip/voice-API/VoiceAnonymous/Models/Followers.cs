﻿namespace VoiceAnonymous.Models
{
    public class Followers
    {
        public int FollowersId { get; set; }
        public string UserName { get; set; }
        public string FollowedUserName { get; set; }
        public bool IsActiveFollows { get; set; }
    }
}
