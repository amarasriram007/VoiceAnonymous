﻿namespace VoiceAnonymous.Models
{
    public class GroupCategoryFollower
    {
        public int GroupCategoryFollowerId { get; set; }
        public string UserName { get; set; }
        public int GroupId { get; set; }
        public string GroupName { get; set; }
        public bool IsJoined { get; set; }
    }
}
