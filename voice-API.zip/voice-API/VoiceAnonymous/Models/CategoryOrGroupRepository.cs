﻿using FuzzySharp;

namespace VoiceAnonymous.Models
{
    public class CategoryOrGroupRepository : ICategoryOrGroupRepository
    {
        private readonly AppDbContext appDbContext;
        public CategoryOrGroupRepository(AppDbContext appDbContext)
        { 
            this.appDbContext = appDbContext;
        }

        public string CreateGroupCategory(CommentCategories category)
        {
            category.isActive = true;
            category.CommentCategoryName = category.CommentCategoryName.Replace(" ", "_");
            this.appDbContext.CommentCategoriesTable.Add(category);
            this.appDbContext.SaveChanges();
            return "Category Group created";
        }


        public string DeleteGroup(int groupId) 
        { 
            var groupInfo = this.appDbContext.CommentCategoriesTable.SingleOrDefault( x => x.CommentCategoriesId == groupId );
            if (groupInfo != null)
            {
                this.appDbContext.CommentCategoriesTable.Remove(groupInfo);
                this.appDbContext.SaveChanges();
                var unfollowingAllForDeletedGroup = this.appDbContext.GroupCategoryFollowerTable.Where( x => x.GroupId == groupId );
                if (unfollowingAllForDeletedGroup != null)
                {
                    this.appDbContext.GroupCategoryFollowerTable.RemoveRange(unfollowingAllForDeletedGroup);
                    this.appDbContext.SaveChanges();
                    return "Group Successfully Deleted";
                }
                return "Group Successfully Deleted";
            }
            return "Group Not Deleted";
        }

        public IEnumerable<CommentCategories> GetAllGroups()
        {
            return this.appDbContext.CommentCategoriesTable.Where( x => x.isActive );
        }


        public string JoiningUserIntoGroup(string UserName, int groupId)
        {
            GroupCategoryFollower groupCategoryFollower = new GroupCategoryFollower();
            var UserExistinUserTable = this.appDbContext.UserNamesTable.Any(x => x.UserName == UserName);
            var Categoryname = this.appDbContext.CommentCategoriesTable.SingleOrDefault(x => x.CommentCategoriesId == groupId);
            if (Categoryname != null && UserExistinUserTable && !ShowJoinOrExitButton(UserName, groupId))
            {
                groupCategoryFollower.IsJoined = true;
                groupCategoryFollower.GroupName = Categoryname.CommentCategoryName;
                groupCategoryFollower.UserName = UserName;
                groupCategoryFollower.GroupId = groupId;
                this.appDbContext.GroupCategoryFollowerTable.Add(groupCategoryFollower);
                this.appDbContext.SaveChanges();
                return "Successfully Joined in New Group";
            }
            return "Unable to Join";
        }
        

        public string ExitFromGroup(string UserName, int groupId) 
        { 
            var UserCanExit = this.appDbContext.GroupCategoryFollowerTable.SingleOrDefault(x => x.UserName == UserName && x.GroupId == groupId);
            if(UserCanExit != null)
            {
                this.appDbContext.GroupCategoryFollowerTable.Remove(UserCanExit);
                this.appDbContext.SaveChanges();
                return "Successfully Exited from group";
            }
            return "Unable to Exit";
        }


        public bool ShowJoinOrExitButton(string UserName, int groupId)
        {
            var joinExitUser = this.appDbContext.GroupCategoryFollowerTable.FirstOrDefault(f => f.UserName == UserName && f.GroupId == groupId);
            if (joinExitUser != null && joinExitUser.IsJoined)
            {
                //true for joined
                return true;
            }
            else
            {
                //false for join
                return false;
            }
        }


        public IEnumerable<GroupCategoryFollower> FollowingListForeachGroup(int groupid)
        {
            return this.appDbContext.GroupCategoryFollowerTable.Where(x => x.GroupId == groupid && x.IsJoined);
        }


        public IEnumerable<CommentCategories> SearchAllGroups(string searchText, double minimumSimilarity)
        {
            //Need to Install FuzzySharp Packages from Nuget Package Store
            if (searchText != null)
            {
                var allGroups = this.appDbContext.CommentCategoriesTable.AsEnumerable();
                var similarMatches = allGroups
                .Where(x => Fuzz.PartialRatio(x.CommentCategoryName.ToLower(), searchText.ToLower()) >= minimumSimilarity);
                return similarMatches;
            }
            return this.appDbContext.CommentCategoriesTable;
        }


        public List<CommentCategories> TrendingTop3Categories()
        {
            List<CommentCategories> TrendingcommentCategories = new List<CommentCategories>();
            var hashtagCounts = this.appDbContext.CommentHashTagsTable
        .GroupBy(x => x.HashTagName)
        .Select(g => new { HashTag = g.Key, Count = g.Count() })
        .OrderByDescending(g => g.Count)
        .Take(5);

            List<string> trendingCategories = hashtagCounts.Select(g => g.HashTag).ToList();

            foreach(var hashtag in trendingCategories)
            {
                var categoryComment = this.appDbContext.CommentCategoriesTable.SingleOrDefault(x => x.CommentCategoryName == hashtag);
                if (categoryComment != null)
                {
                    TrendingcommentCategories.Add(categoryComment);
                }
            }
            return TrendingcommentCategories;
        }
    }
}
