﻿namespace VoiceAnonymous.Models
{
    public interface ICategoryOrGroupRepository
    {
        public string CreateGroupCategory(CommentCategories category);
        public IEnumerable<CommentCategories> GetAllGroups();
        public string JoiningUserIntoGroup(string UserName, int groupId);
        public string ExitFromGroup(string UserName, int groupId);
        public bool ShowJoinOrExitButton(string UserName, int groupId);
        public IEnumerable<GroupCategoryFollower> FollowingListForeachGroup(int groupid);
        public string DeleteGroup(int groupId);
        public IEnumerable<CommentCategories> SearchAllGroups(string searchText, double minimumSimilarity);
        public List<CommentCategories> TrendingTop3Categories();
    }
}
