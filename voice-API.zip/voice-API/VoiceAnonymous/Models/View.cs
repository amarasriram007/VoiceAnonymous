﻿namespace VoiceAnonymous.Models
{
    public class View
    {
        public int ViewId { get; set; }
        public int CommentIds { get; set; }
        public string UserName { get; set; }
    }
}
