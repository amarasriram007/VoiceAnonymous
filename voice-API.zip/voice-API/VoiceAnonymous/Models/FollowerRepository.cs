﻿namespace VoiceAnonymous.Models
{
    public class FollowerRepository : IFollowerRepository
    {
        private readonly AppDbContext appDbContext;
        public FollowerRepository(AppDbContext appDbContext)
        {
            this.appDbContext = appDbContext;
        }
        public IEnumerable<Followers> GetAllFollwersForSelectedUser(string UserName)
        {
            return this.appDbContext.FollowerTable.Where( x => x.UserName == UserName && x.IsActiveFollows);
        }


        public bool AddFollower(string UserName, string FollowedUserName)
        {
            var UserNamesExist = this.appDbContext.UserNamesTable.Any( x => x.UserName == UserName );
            var FollowedUserNameExist = this.appDbContext.UserNamesTable.Any( x => x.UserName == FollowedUserName );
            var FollowedStatus = GetFollowButtonStatus(UserName, FollowedUserName);
            if (UserName != FollowedUserName && UserNamesExist && FollowedUserNameExist && FollowedStatus == "Follow")
            {
                Followers follower = new Followers();
                follower.UserName = UserName;
                follower.FollowedUserName = FollowedUserName;
                follower.IsActiveFollows = true;
                this.appDbContext.FollowerTable.Add(follower);
                this.appDbContext.SaveChanges();
                return true;
            }
            return false;
        }


        public bool RemoveFollower(string UserName, string FollowedUserName)
        {
            Followers follower = this.appDbContext.FollowerTable.SingleOrDefault( x => x.IsActiveFollows && x.UserName == UserName && x.FollowedUserName == FollowedUserName);
            if (follower != null )
            {
                this.appDbContext.FollowerTable.Remove(follower);
                this.appDbContext.SaveChanges();
                return true;
            }
            return false;
        }


        public IEnumerable<Followers> FollowingList(string UserName)
        {
           return  this.appDbContext.FollowerTable.Where(x => x.FollowedUserName == UserName);
        }

        public string GetFollowButtonStatus(string username, string followedUsername)
        {
            var follower = this.appDbContext.FollowerTable.FirstOrDefault(f => f.UserName == username && f.FollowedUserName == followedUsername);
            if (follower != null && follower.IsActiveFollows)
            {
                return "Following";
            }
            else
            {
                return "Follow";
            }
        }


    }
}
