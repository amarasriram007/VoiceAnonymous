﻿namespace VoiceAnonymous.Models
{
    public interface IFollowerRepository
    {
        public IEnumerable<Followers> GetAllFollwersForSelectedUser(string UserName);
        public bool AddFollower(string UserName, string FollowedUserName);
        public bool RemoveFollower(string UserName, string FollowedUserName);
        public string GetFollowButtonStatus(string username, string followedUsername);
        public IEnumerable<Followers> FollowingList(string UserName);
    }
}
