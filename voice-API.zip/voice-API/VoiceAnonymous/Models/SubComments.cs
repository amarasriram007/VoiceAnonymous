﻿namespace VoiceAnonymous.Models
{
    public class SubComments
    {
        public int SubCommentsId { get; set; }
        public int CommentIds { get; set; }
        public string UserName { get; set; }
        public string? SubCommentText { get; set; }
        public string? subCommentSentiment { get; set; }
    }
}
