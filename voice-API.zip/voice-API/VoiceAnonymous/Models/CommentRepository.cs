﻿using FuzzySharp;
using System.Linq;
using System.Text.RegularExpressions;

namespace VoiceAnonymous.Models
{
    public class CommentRepository : ICommentsRepository
    {
        private readonly AppDbContext appDbContext;
        public CommentRepository(AppDbContext appDbContext)
        {
            this.appDbContext = appDbContext;
        }
        public IEnumerable<Comment> GetAll()
        {
            var AllComments =  this.appDbContext.CommentTable.Where( x => x.Visibility == "Public");
            List<Comment> allTimeConvertedComments = new List<Comment>();
            if (AllComments != null)
            {
                foreach (var comment in AllComments)
                {
                    comment.TimeConverted = (GetTimeIntoHoursDaysAgoConverter(comment.CommentId));
                    allTimeConvertedComments.Add(comment);
                }
            }
            return allTimeConvertedComments.OrderByDescending( x => x.CommentId);
        }


        public Comment GetCommentById(int CommentId)
        {
            return GetAll().SingleOrDefault(x => x.CommentId == CommentId);
        }


        public IEnumerable<Comment> GetCommentsByUserNameIds(string UserName)
        {
            var AllComments = this.appDbContext.CommentTable.Where( x => x.UserName == UserName );
            List<Comment> allTimeConvertedComments = new List<Comment>();
            if (AllComments != null)
            {
                foreach (var comment in AllComments)
                {
                    comment.TimeConverted = (GetTimeIntoHoursDaysAgoConverter(comment.CommentId));
                    allTimeConvertedComments.Add(comment);
                }
            }
            return allTimeConvertedComments.OrderByDescending(x => x.CommentId);
        }


        public string ViewOrHideComment(int CommentId, string ViewOrHide)
        {
            var comment = this.appDbContext.CommentTable.SingleOrDefault( x => x.CommentId == CommentId );
            if (comment != null)
            {
                comment.Visibility = ViewOrHide;
                this.appDbContext.CommentTable.Update( comment );
                this.appDbContext.SaveChanges();
                return "Comment visibility Changed";
            }
            return "Comment Visibility Not Changed";

        }


        public bool AddNewComments(Comment comment)
        {
            var UserExist = this.appDbContext.UserNamesTable.Any( x => x.UserName== comment.UserName );
            if (comment.UserName != null && comment.CommentText != null && UserExist)
            {
                var Hashtag = ExtractHashTagFromComment(comment.CommentText);
                if (Hashtag.Length > 0)
                {
                    var CategoryIdFromHashtag = GetCategoryIdFromCategoryTable(Hashtag[0]);
                    if (CategoryIdFromHashtag != null && CategoryIdFromHashtag > 0)
                    {
                        comment.CommentCategoryIds = CategoryIdFromHashtag;
                    }
                    else
                    {
                        comment.CommentCategoryIds = 1;
                    }
                }
                else
                {
                    comment.CommentCategoryIds = 1;
                }
                    comment.CreatedDateTime = DateTime.Now;
                    comment.ViewsCount = 1;
                    comment.LikesCount = 0;
                    var entity = this.appDbContext.CommentTable.Add(comment);
                    this.appDbContext.SaveChanges();
                    insertHashTag(entity.Entity.CommentId, entity.Entity.CommentText);
                    return true;
            }
                return false;
        }


        public bool insertHashTag(int commentId, string commentText)
        {
            var HashTagsForComment = ExtractHashTagFromComment(commentText);
            if (HashTagsForComment != null)
            {
                List<CommentHashTag> commentHashTagList = new List<CommentHashTag>();
                foreach (var tag in HashTagsForComment)
                {
                    var TagNameInCategory = this.appDbContext.CommentCategoriesTable.Where(x => x.CommentCategoryName == tag).Select(x => x.CommentCategoriesId).SingleOrDefault();
                    if (TagNameInCategory != null && TagNameInCategory>0)
                    {
                        CommentHashTag commentHashTag = new CommentHashTag();
                        commentHashTag.CommentIds = commentId;
                        commentHashTag.HashTagName = tag;
                        commentHashTag.CommentCategoriesIds = TagNameInCategory;
                        commentHashTagList.Add(commentHashTag);
                    }
                }
                if (commentHashTagList.Count > 0)
                {
                    this.appDbContext.CommentHashTagsTable.AddRange(commentHashTagList);
                    this.appDbContext.SaveChanges();
                }
                return true;
            }
            return false;
        }


        public bool UpdateComment(Comment comment)
        {
            var commentTextToUpdate = this.appDbContext.CommentTable.SingleOrDefault(x => x.UserName == comment.UserName && x.CommentId == comment.CommentId);
            if (commentTextToUpdate != null)
            {
                var Hashtag = ExtractHashTagFromComment(comment.CommentText);
                if (Hashtag.Length > 0)
                {
                    ChangeCommentHashtagIfUpdate(comment.CommentId);
                    insertHashTag(comment.CommentId, comment.CommentText);
                    var CategoryIdFromHashtag = GetCategoryIdFromCategoryTable(Hashtag[0]);
                    if (CategoryIdFromHashtag != null && CategoryIdFromHashtag > 0)
                    {
                        comment.CommentCategoryIds = CategoryIdFromHashtag;
                    }
                    else
                    {
                        comment.CommentCategoryIds = 1;
                    }
                }
                else
                {
                    comment.CommentCategoryIds = 1;
                }
                commentTextToUpdate.CommentText = comment.CommentText;
                commentTextToUpdate.Visibility=comment.Visibility;
                commentTextToUpdate.CommentCategoryIds = comment.CommentCategoryIds;
                commentTextToUpdate.commentSentiment = comment.commentSentiment;
                this.appDbContext.CommentTable.Update(commentTextToUpdate);
                this.appDbContext.SaveChanges();
                return true;
            }
                return false;
        }
       

        public bool ChangeCommentHashtagIfUpdate(int commentId)
        {
            var AllHashTags = this.appDbContext.CommentHashTagsTable.Where(x => x.CommentIds == commentId);
            if(AllHashTags != null)
            {
                this.appDbContext.CommentHashTagsTable.RemoveRange(AllHashTags);
                this.appDbContext.SaveChanges(); 
                return true;
            }
            return false;
        }


        public int GetCategoryIdFromCategoryTable(string Hashtag)
        {
            var itemId =  this.appDbContext.CommentCategoriesTable.SingleOrDefault(x => x.CommentCategoryName == Hashtag);
            if(itemId != null && itemId.CommentCategoriesId > 0)
            {
                return itemId.CommentCategoriesId;
            }
            return 1;
        }


        public string DeleteOrDeactivateComment(int  commentId, string UserName)
        {
            var comment = this.appDbContext.CommentTable.SingleOrDefault(x => x.UserName == UserName && x.CommentId == commentId);
            var AllSubCommentsByCommentId = this.appDbContext.SubCommentsTable.Where(x => x.CommentIds == commentId);
            if (comment != null)
            {
                this.appDbContext.CommentTable.Remove( comment );
                this.appDbContext.SaveChanges();
                if (AllSubCommentsByCommentId != null)
                {
                    this.appDbContext.SubCommentsTable.RemoveRange(AllSubCommentsByCommentId);
                    this.appDbContext.SaveChanges();
                }
                return "Comment Deleted";
            }
            return "Comment Not Deleted";
        }


        public bool UpdateLikesCounts(int commentId, string commentUserName)
        {
            if(commentId > 0 && commentUserName != null) 
            { 
                var UpdateLikesCount = this.appDbContext.CommentTable.SingleOrDefault(x => x.CommentId == commentId);
                if (UpdateLikesCount != null && checkUserExistsOrNot(commentUserName))
                {
                    if (!CheckLikedStatusForComment(commentId, commentUserName))
                    {
                        CommentsLikedUsers(commentId, commentUserName);
                        UpdateLikesCount.LikesCount++;
                        this.appDbContext.CommentTable.Update(UpdateLikesCount);
                        this.appDbContext.SaveChanges();
                        return true;
                    }
                }
            }
            return false;
        }


        public string UpdateCategoryIdIfChanged(int CommentId, int categoryId)
        {
            var comment = this.appDbContext.CommentTable.SingleOrDefault(x => x.CommentId == CommentId);
            if (comment != null)
            {
                comment.CommentCategoryIds = categoryId;
                this.appDbContext.CommentTable.Update(comment);
                this.appDbContext.SaveChanges();
                return "Category Changed for Comment";
            }
            return "Category Not Changed";
        }


        public bool UpdateViewsCounts(int commentId, string commentUserName)
        {
            var UpdateLikesCount = this.appDbContext.CommentTable.SingleOrDefault(x => x.UserName == commentUserName && x.CommentId == commentId);
            var userViewedStatus = this.appDbContext.ViewsTable.Any(x => x.CommentIds == commentId && x.UserName == commentUserName);
            if (UpdateLikesCount != null && userViewedStatus)
            {
                CommentsViewedUsers(commentId, commentUserName);
                UpdateLikesCount.ViewsCount++;
                this.appDbContext.CommentTable.Update(UpdateLikesCount);
                this.appDbContext.SaveChanges();
                return true;
            }
            return false;
        }
        public bool DecreamentUpdateLikesCounts(int commentId, string commentUserName)
        {
            if (commentId > 0 && commentUserName != null)
            {
                var UpdateLikesCount = this.appDbContext.CommentTable.SingleOrDefault(x => x.CommentId == commentId);
                if (UpdateLikesCount != null && CommentUnLikingUsers(commentId, commentUserName))
                {
                    UpdateLikesCount.LikesCount = (UpdateLikesCount.LikesCount > 0) ? (UpdateLikesCount.LikesCount - 1) : 0;
                    this.appDbContext.CommentTable.Update(UpdateLikesCount);
                    this.appDbContext.SaveChanges();
                    return true;
                }
            }
            return false;
        }


        public string GetTimeIntoHoursDaysAgoConverter(int commentId)
        {
            DateTime? commentDateTime = this.appDbContext.CommentTable.SingleOrDefault(x => x.CommentId == commentId).CreatedDateTime;
            if (commentDateTime != null)
            {
                TimeSpan timeDifference = (TimeSpan)(DateTime.Now - commentDateTime);

                if (timeDifference.TotalMinutes < 1)
                {
                    return ("just now");
                }
                else if (timeDifference.TotalHours < 1)
                {
                    int minutesAgo = (int)timeDifference.TotalMinutes;
                    return ($"{minutesAgo} min{(minutesAgo != 1 ? "s" : "")} ago");
                }
                else if (timeDifference.TotalHours < 24)
                {
                    int hoursAgo = (int)timeDifference.TotalHours;
                    return ($"{hoursAgo} hour{(hoursAgo != 1 ? "s" : "")} ago");
                }
                else
                {
                    return ($"{commentDateTime}");
                }

            }
            return "failed";
        }


        public bool checkUserExistsOrNot(string UserName)
        {
            return this.appDbContext.UserNamesTable.Any(x => x.UserName == UserName);
        }

        //SubComment APIs
        public bool AddNewSubComments(SubComments SubComment)
        {
            var CheckCommentIdAvailable = this.appDbContext.CommentTable.Any(x => x.CommentId == SubComment.CommentIds);
            if (SubComment != null && CheckCommentIdAvailable && checkUserExistsOrNot(SubComment.UserName))
            {
                this.appDbContext.SubCommentsTable.Add(SubComment);
                this.appDbContext.SaveChanges();
                
                return true;
            }
                return false;
        }


        public IEnumerable<SubComments> GetAllSubCommentsByCommentId(int commentId)
        {
            return this.appDbContext.SubCommentsTable.Where(x=>x.CommentIds==commentId);
        }


        public string DeleteSubComment(int SubCommentId, string username)
        {
            var SubComment = this.appDbContext.SubCommentsTable.SingleOrDefault( x => x.SubCommentsId==SubCommentId && x.UserName == username);
            if (SubComment != null)
            {
                this.appDbContext.SubCommentsTable.Remove(SubComment);
                this.appDbContext.SaveChanges();
                return "SubComment Successfully Deleted";
            }
            return "SubComment not deleted";
        }


        public string EditSubComment(SubComments subComments)
        {
            var subcommentDb = this.appDbContext.SubCommentsTable.SingleOrDefault( x => x.SubCommentsId == subComments.SubCommentsId &&  x.UserName == subComments.UserName);
            if (subcommentDb != null)
            {
                subcommentDb.SubCommentText = subComments.SubCommentText;
                subcommentDb.subCommentSentiment = subComments.subCommentSentiment;
                this.appDbContext.SubCommentsTable.Update(subcommentDb);
                this.appDbContext.SaveChanges();
                return "Succesfully Edited";
            }
            return "Unable to Edit";
        }


        public bool CommentsLikedUsers(int commentId, string  UserName)
        {
            Likes likes = new Likes();
            likes.UserName = UserName;
            likes.CommentIds = commentId;
            this.appDbContext.LikesTable.Add(likes);
            this.appDbContext.SaveChanges();
            return true;
        }


        public bool CheckLikedStatusForComment(int commentId, string UserName)
        {
            return this.appDbContext.LikesTable.Any(x => x.CommentIds == commentId && x.UserName == UserName);
        }


        public bool CommentUnLikingUsers(int commentId, string UserName)
        {
                var like = this.appDbContext.LikesTable.SingleOrDefault(x => x.UserName == UserName && x.CommentIds == commentId);
            if (like != null)
            {
                this.appDbContext.LikesTable.Remove(like);
                this.appDbContext.SaveChanges();
                return true;
            }
      
            return false;
        }

        public IEnumerable<Likes> GetAllLikesByCommentId(int commentId)
        {
            return this.appDbContext.LikesTable.Where(x => x.CommentIds == commentId);
        }


        public bool CommentsViewedUsers(int commentId, string UserName)
        {
            View views = new View();
            views.UserName = UserName;
            views.CommentIds = commentId;
            this.appDbContext.ViewsTable.Add(views);
            this.appDbContext.SaveChanges();
            return true;
        }


        public string[] ExtractHashTagFromComment(string CommentText)
        {
            Regex regex = new Regex(@"#(\w+)");
            MatchCollection matches = regex.Matches(CommentText);
            string[] extractedHashtags = new string[matches.Count];
            for (int i = 0; i < matches.Count; i++)
            {
                extractedHashtags[i] = matches[i].Groups[1].Value;
            }
                return extractedHashtags;          
        }


        public IEnumerable<Comment> GetAllCommentsByHashTag(string hashTag)
        {
            List<int> AllCommentIdsForHashTags = new List<int>();
            List<Comment> allCommentsData = new List<Comment>();    
            var minimumSimilarity = 80.0;
            var allGroups = this.appDbContext.CommentCategoriesTable.AsEnumerable();
            var CategorysimilarMatches = allGroups
            .Where(x => Fuzz.PartialRatio(x.CommentCategoryName.ToLower(), hashTag.ToLower()) >= minimumSimilarity);
            if(CategorysimilarMatches != null)
            {
                
                foreach (var categoryName in CategorysimilarMatches)
                {
                    var commentId = this.appDbContext.CommentHashTagsTable.Where(x => x.HashTagName == categoryName.CommentCategoryName).Select(x => x.CommentIds);
                    if(commentId != null)
                    {
                        AllCommentIdsForHashTags.AddRange(commentId);
                    }
                }
                if (AllCommentIdsForHashTags.Count > 0)
                {
                    AllCommentIdsForHashTags.Distinct();
                    var commentData = this.appDbContext.CommentTable.Where(x => AllCommentIdsForHashTags.Contains(x.CommentId));
                    if (commentData != null)
                    {
                        return commentData;
                    }
                }
            }
            return allCommentsData;
        }


        public bool GetLikeButtonStatus(int commentId, string UserName)
        {
            //true means Liked, False means Not Liked
            return this.appDbContext.LikesTable.Any(x => x.CommentIds == commentId && x.UserName == UserName);
        }


        public IEnumerable<Comment> GetAllTrendingCommments()
        {
            var allComments = GetAll();
            var allsubcomments = this.appDbContext.SubCommentsTable;
            var commentScores = allComments.Select(c => new
            {
                Comment = c,
                Score = c.ViewsCount + c.LikesCount + allsubcomments.Count(s => s.CommentIds == c.CommentId)
            });
            var sortedComments = commentScores.OrderByDescending(cs => cs.Score)
                                             .Select(cs => cs.Comment);

            return sortedComments.Take(5);
        }
    }
}
