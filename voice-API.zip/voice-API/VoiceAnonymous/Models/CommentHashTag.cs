﻿using System.ComponentModel.DataAnnotations.Schema;

namespace VoiceAnonymous.Models
{
    public class CommentHashTag
    {
        public int CommentHashTagId { get; set; }     
        public string HashTagName { get; set; }
        public int CommentIds { get; set; }      
        public int CommentCategoriesIds { get; set; }

    }
}
