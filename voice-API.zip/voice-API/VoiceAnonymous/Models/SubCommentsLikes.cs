﻿namespace VoiceAnonymous.Models
{
    public class SubCommentsLikes
    {
        public int SubCommentsLikesId { get; set; }
        public int SubCommentIds { get; set; }
        public string UserName { get; set; }
        public int LikeCount { get; set; }
    }
}
