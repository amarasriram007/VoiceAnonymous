﻿using Microsoft.EntityFrameworkCore;

namespace VoiceAnonymous.Models
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {

        }
        public DbSet<UserNames> UserNamesTable { get; set; }
        public DbSet<Comment> CommentTable { get; set; }
        public DbSet<CommentCategories> CommentCategoriesTable { get; set; }
        public DbSet<SubComments> SubCommentsTable { get; set; }
        public DbSet<SubCommentsLikes> SubCommentsLikesTable { get; set; }
        public DbSet<Followers> FollowerTable { get; set; }
        public DbSet<GroupCategoryFollower> GroupCategoryFollowerTable { get; set; }
        public DbSet<Likes> LikesTable { get; set; }
        public DbSet<View> ViewsTable { get; set; }
        public DbSet<CommentHashTag> CommentHashTagsTable { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Comment>().HasData(new Comment
            {
                CommentId = 1,
                UserName = "Test",
                CommentText = "Test",
                CreatedDateTime = DateTime.Now,
                Visibility="Public",
                CommentCategoryIds = 1,
                ViewsCount = 1,
                LikesCount = 1,
            });
            modelBuilder.Entity<UserNames>().HasData(new UserNames
            {
                UserName = "navex",
                IsActive = true,
                Email = "test@gmail.com",
                password = "Sriram@123",
                ConfirmPassword = "Sriram@123",
                CompanyName = "GL",
                PhoneNumber = "8523863007",
            });
            modelBuilder.Entity<CommentCategories>().HasData(new CommentCategories
            {
                CommentCategoriesId = 1,
                CommentCategoryName = "Other",
                CommentCategoryDescription = "Other",
                isActive = true,
            });
        }
        }

}
