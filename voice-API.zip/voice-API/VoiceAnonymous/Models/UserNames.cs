﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace VoiceAnonymous.Models
{
    public class UserNames
    {
        [Key]
        [Required]
        public string UserName { get; set; }
        public string CompanyName { get; set; }
        public bool IsActive { get; set; }
        [PasswordPropertyText]
        public string password { get; set; }
        public string ConfirmPassword { get; set; }
        [EmailAddress]
        public string Email { get; set; }
        [Required]
        [Phone]
        public string PhoneNumber { get; set; }
        public string? StaticProfilePath { get; set; }

    }
}
