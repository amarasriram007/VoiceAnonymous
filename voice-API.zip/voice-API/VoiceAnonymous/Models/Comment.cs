﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace VoiceAnonymous.Models
{
    public class Comment
    {
        public int CommentId { get; set; }
        [Required]
        public string UserName { get; set; }
        [Required]
        public string? CommentText { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        [Required]
        [RegularExpression("^(Private|Public)$", ErrorMessage = "Must be Public or Private visible")]
        public string Visibility { get; set; } = "Public";
        public int CommentCategoryIds { get; set; }
        public int? ViewsCount { get; set; } = 0;
        public int LikesCount { get; set; } = 0;
        [NotMapped]
        public string ? TimeConverted { get; set; }
        public string ? commentSentiment { get; set; }
    }
}
