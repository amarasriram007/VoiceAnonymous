﻿using System.ComponentModel.DataAnnotations;

namespace VoiceAnonymous.Models
{
    public class CommentCategories
    {
        public int CommentCategoriesId { get; set; }
        [Required]
        public string CommentCategoryName { get; set;}
        public string CommentCategoryDescription { get; set;}
        public bool isActive { get; set;}
    }
}
