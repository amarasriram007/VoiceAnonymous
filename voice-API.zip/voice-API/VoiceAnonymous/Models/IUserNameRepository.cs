﻿namespace VoiceAnonymous.Models
{
    public interface IUserNameRepository
    {
        public bool CheckUniqueUserName(string userName);
        public bool AddUserName(UserNames UserProfile);
        public bool UpdateUserData(UserNames UserProfile);
        public IEnumerable<UserNames> GetAllUserProfiles();
        public UserNames GetUserProfileByUserName(string UserName);
        public string DeleteUserProfiles(string UserName);
        public string EncryptData(string phoneNumber);
        public string DecryptData(string encryptedPhoneNumber);
        public string LoginData(string username, string password);
        public bool LogOut(string username);
    }
}
