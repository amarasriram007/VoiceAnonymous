﻿namespace VoiceAnonymous.Models
{
    public class Likes
    {
        public int LikesId { get; set; }
        public int CommentIds { get; set; }
        public string UserName { get; set; }
    }
}
